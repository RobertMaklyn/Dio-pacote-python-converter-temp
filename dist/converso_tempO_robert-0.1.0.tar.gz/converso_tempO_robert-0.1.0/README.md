# temp_converter

Um pacote simples para conversão de temperaturas entre Celsius, Fahrenheit e Kelvin.

## Instalação

```bash
pip install temp_converter

